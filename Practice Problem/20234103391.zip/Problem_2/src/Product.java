public interface Product {
    Colour getColour();
}
