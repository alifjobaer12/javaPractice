package package2;

import package1.Laibrary;

public class Reader extends Laibrary {
    public void readBook() {
        super.showBook();
    }
}
