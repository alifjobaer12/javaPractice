package package1;

public class Laibrary {
    protected void showBook() {
        System.out.println("Book available: Java Programming");
    }
}
